                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:176391
Winter Treeman (18mm scale) by dutchmogul is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

This character was designed for our sci-fantasy tabletop RPG, [Wayfarer: Things Beyond Wonder](http://www.illgottengames.net/wayfarer/) and for our modular wargaming system, [Wayfarer Tactics](http://www.illgottengames.net/products/second-edition-wayfarer-tactics) (now in Second Edition!). If you want to print a 28mm scale version, just scale it up by 166.6%.

We've set up a [Patreon page](https://www.patreon.com/illgottengames) for anyone who's interested in helping to fund us so we can keep making free and open sourced games like Pocket-Tactics, Wayfarer Tactics. and others, not to mention the growing catalog of gaming miniatures that you can use for whatever you want! (Psst... we take requests and commissions...)

Enjoy!