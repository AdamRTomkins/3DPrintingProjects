                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:2917932
2020 / Ender 3 Filament Guide by Filboyt is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

Snap In Guide, Many to choose from!

The Base Will fit tight but should not need any trimming, tested at a few resolutions.
Once its in the aluminum just click your guide in and call it a day.

Version 3 Is here, Optimized and should have no Ring print issues at any resolution.

If your printer hates to bridge, Print end clip with support lines at 1.8mm apart (5 lines total under roof) only touching build plate. 

End Clip has been repaired, rear prongs are Back to thickness of original
Don't forget to cut any strands filling the top pillar or it will provide a lot of resistance.

For those who have tipped me a coffee, I offer back a huge thanks.
For those who wish to, I drink the cheap stuff. 



# Print Settings

Printer: Ender 3
Rafts: Doesn't Matter
Supports: No
Resolution: .1 to .18
Infill: 10% +