                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:3026123
Ender 3 Tool Holder by Pickle_Rick_1 is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

Nothing wrong with other tool holders, this fit my requirements best. It hold all stock supplied tools that come with the Ender 3, there is even a spot for the SD Card. it sits on top of the power supply. 

Updated 9/16/18
-Rev2 
-Additional Piece

Per Community Suggestions:
1--More storage space for small and large SD's
2--place for cutters on the front
3--more support in the rear to contact power supply

I added the additional supports (1mm) each side and included it as .stl (rev2). The additional storage and mount for the side cutter is simply a new piece that fits into the existing tool holder. Hope others find this useful!

# Print Settings

Printer Brand: Creality
Printer: Ender 3
Rafts: No
Supports: Yes
Infill: 20