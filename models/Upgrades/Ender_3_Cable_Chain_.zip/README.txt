                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2920060
Ender 3 Cable Chain  by johnniewhiskey is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

Update [10:53 PM 2018-06-16] 

- Added parts assembly guide image 

- cableChain_link_v3.stl 
Not constraint hinge to 1 direction anymore (But v2 still work fine) 
15 links for heatbed, 10-15 links for gantry.

- cableChain_bedCorner_v2.stl (and Cover)
Easier Snap assembly and disassembly

- cableChain_40MountTop_v2.stl 
Better hinge rotation range for tall print

- cableChain_40MountSide_v2.stl
Offset more to better align with heatbed mount

================================================================
Update [1:54 AM 2018-06-11]
Added Improved version

- cableChain_link_v2.stl << Main chain body 
- cableChain_linkCover_v2.stl << Chain part 
 
- cableChain_plateMount_v2.stl << Snap fit to that black 'Bed Wiring Mount' stock part 

**New Parts**
- cableChain_bedCorner.stl << Replace that black 'Bed Wiring Mount' stock part 

================================================================
Ender 3 Cable Chain 

- For Creality Ender 3 rear cable. 
- Keep it Neat and Cool. 
- Snap design. No need screw or nut.
- Print without support. 

15 Links for Heatbed.
10 Links (or more) for X gantry.

Please Share Your MAKE, Thank you.

[10:07 PM 2018-05-19]


# Print Settings


Notes: 
Use a little higher print temp than usual for stronger part. 
Too low temp will cause part break while assembly.